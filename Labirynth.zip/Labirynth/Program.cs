﻿using System;
using System.Collections.Generic;

class LabyrinthPathFinder
{
    static void Main()
    {
        // Пример лабиринта: 1 - открытый квадрат, 0 - закрытый
        int[,] labyrinth = {
            { 1, 1, 1, 0, 0 },
            { 0, 0, 1, 0, 0 },
            { 1, 1, 1, 1, 1 },
            { 1, 0, 0, 0, 1 },
            { 1, 1, 1, 1, 1 }
        };

        Console.WriteLine("Введите координаты входа (x, y):");
        int startX = int.Parse(Console.ReadLine());
        int startY = int.Parse(Console.ReadLine());

        Console.WriteLine("Введите координаты выхода (x, y):");
        int endX = int.Parse(Console.ReadLine());
        int endY = int.Parse(Console.ReadLine());

        List<(int, int)> path = FindPath(labyrinth, startX, startY, endX, endY);

        if (path != null)
        {
            Console.WriteLine("Найденный путь:");
            foreach (var step in path)
            {
                Console.WriteLine($"({step.Item1}, {step.Item2})");
            }
        }
        else
        {
            Console.WriteLine("Путь не найден.");
        }
    }

    static List<(int, int)> FindPath(int[,] labyrinth, int startX, int startY, int endX, int endY)
    {
        int rows = labyrinth.GetLength(0);
        int cols = labyrinth.GetLength(1);
        bool[,] visited = new bool[rows, cols];
        Stack<(int, int)> stack = new Stack<(int, int)>();
        List<(int, int)> path = new List<(int, int)>();

        stack.Push((startX, startY));

        while (stack.Count > 0)
        {
            var current = stack.Pop();
            int x = current.Item1;
            int y = current.Item2;

            if (x < 0 || x >= rows || y < 0 || y >= cols || labyrinth[x, y] == 0 || visited[x, y])
                continue;

            visited[x, y] = true;
            path.Add((x, y));

            if (x == endX && y == endY)
                return path;

            // Добавляем соседей (вверх, вниз, влево, вправо)
            stack.Push((x - 1, y)); // вверх
            stack.Push((x + 1, y)); // вниз
            stack.Push((x, y - 1)); // влево
            stack.Push((x, y + 1)); // вправо
        }

        return null; // Путь не найден
    }
}
